import mysql.connector
from faker import Faker
from faker.providers import DynamicProvider
mydb=mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="grocery_store"
)
mycursor=mydb.cursor()
fake=Faker()
tables = ['baby_care', 'bathroom', 'beauty_products', 'brings', 'cart_attendant', 'cashier', 'cleaning_supplies', 'customer', 'discount_paper', 'food', 'items', 'janitor', 
          'kitchen_tools', 'medicine', 'pet_care', 
          'receipt', 'review', 'stock_clerk', 'supplier', 'uses', 'writes']
#baby care

for _ in range(100):
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_tooltype = fake.random_element(elements=('Type1', 'Type2', 'Type3', 'Type4'))
    query = f"INSERT INTO baby_care (barcode_number, tooltype) VALUES ({fake_barcode_number}, '{fake_tooltype}')"
    mycursor.execute(query)
    
#bathroom
for _ in range(5):
    fake_bathroom_id=fake.unique.random_number(digits=5)
    query = f"INSERT INTO bathroom (bathroom_id) VALUES ({fake_bathroom_id})"
    mycursor.execute(query)
 #beauty_products   
for _ in range(100):
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_typeitem = fake.random_element(elements=('Type1', 'Type2', 'Type3', 'Type4'))
    query = f"INSERT INTO beauty_products (barcode_number, typeitem) VALUES ({fake_barcode_number}, '{fake_typeitem}')"
    mycursor.execute(query)
  

#cart_attendant    
for _ in range(50):
    fake_Employee_ID=fake.unique.random_number(digits=5)
    fake_name_attendant = fake.name()
    fake_retrieval_rate = fake.random_number(digits=1)
    query = f"INSERT INTO cart_attendant (Employee_ID, name_attendant, retrieval_rate) VALUES ({fake_Employee_ID}, '{fake_name_attendant}',{fake_retrieval_rate})"
    mycursor.execute(query)
#cashier
for _ in range(50):
    fake_Employee_ID=fake.unique.random_number(digits=5)
    fake_name_cashier = fake.name()
    fake_register_number = fake.random_number(digits=1)
    query = f"INSERT INTO cashier (Employee_ID, name_cashier, register_number) VALUES ({fake_Employee_ID}, '{fake_name_cashier}',{fake_register_number})"
    mycursor.execute(query)
#cleaning supplies    
for _ in range(100):
    
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_size = fake.random_element(elements=('Small', 'Medium', 'Large'))
    query = f"INSERT INTO cleaning_supplies (barcode_number, size) VALUES ({fake_barcode_number}, '{fake_size}')"
    mycursor.execute(query)
#customer    
for _ in range(200):
    
    fake_Membership_ID=fake.unique.random_number(digits=5)
    fake_name_customer = fake.name()
    query = f"INSERT INTO customer (Membership_ID, name_customer) VALUES ({fake_Membership_ID}, '{fake_name_customer}')"
    mycursor.execute(query)
#discount_paper    
for _ in range(200):
    
    fake_Paper_ID=fake.unique.random_number(digits=5)
    query = f"INSERT INTO discount_paper (Paper_ID) VALUES ({fake_Paper_ID})"
    mycursor.execute(query)
#food


#items    

#janitor    
for _ in range(50):
    
    fake_employee_id=fake.unique.random_number(digits=5)
    fake_name_janitor = fake.name()
    fake_cleaning_task = fake.random_element(elements=('Toilets','Sweeping','Mopping','Dusting','Organizing'))
    query = f"INSERT INTO janitor (employee_id, name_janitor, cleaning_task ) VALUES ({fake_employee_id}, '{fake_name_janitor}','{fake_cleaning_task}')"
    mycursor.execute(query)
    
#kitchen_tools    
for _ in range(100):
    
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_tool_type = fake.random_element(elements=('Fork','Knife','Spoon'))
    query = f"INSERT INTO kitchen_tools (barcode_number, tool_type) VALUES ({fake_barcode_number}, '{fake_tool_type}')"
    mycursor.execute(query)
    
 #medicine   
for _ in range(100):
    
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_expiration_date=fake.date_this_year()
    fake_consumption_method =fake.random_element(elements=('Nasal','Oral'))
    fake_duration_of_use=fake.random_number(digits=1)
    query = f"INSERT INTO medicine (barcode_number, expiration_date, consumption_method, duration_of_use) VALUES ({fake_barcode_number}, '{fake_expiration_date}','{fake_consumption_method}',{fake_duration_of_use})"
    mycursor.execute(query)
    
    
#pet_care    
for _ in range(100):
    
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_type_care = fake.random_element(elements=('Toy','Food','Grooming'))
    query = f"INSERT INTO pet_care (barcode_number, type_care) VALUES ({fake_barcode_number}, '{fake_type_care}')"
    mycursor.execute(query)
    
    
#receipt    

    
    

    
 #stock_clerk   
for _ in range(50):
    
    fake_Employee_ID=fake.unique.random_number(digits=5)
    fake_name_clerk = fake.name()
    fake_stocking_schedule=fake.random_number(digits=1)
    query = f"INSERT INTO stock_clerk (Employee_ID, name_clerk, stocking_schedule) VALUES ({fake_Employee_ID}, '{fake_name_clerk}',{fake_stocking_schedule})"
    mycursor.execute(query)
    
    
#supplier    
for _ in range(25):
    
    fake_supplier_id=fake.unique.random_number(digits=5)
    fake_name_supplier = fake.company()
    query = f"INSERT INTO supplier (supplier_id, name_supplier) VALUES ({fake_supplier_id}, '{fake_name_supplier}')"
    mycursor.execute(query)

#food
for _ in range(200):
    fake_barcode_number=fake.unique.random_number(digits=8)
    fake_weight = fake.random_number(digits=2)
    fake_expiration_date=fake.date_this_year()
    query = f"INSERT INTO food (barcode_number, weight, expiration_date) VALUES ({fake_barcode_number},{fake_weight},'{fake_expiration_date}')"
    mycursor.execute(query)
    

#review
for _ in range(200):
    fake_review_id = fake.unique.random_number(digits=5)
    mycursor.execute("SELECT Membership_ID FROM customer")
    membership_ids = mycursor.fetchall()
    fake_membership_id = fake.random_element(elements=[id[0] for id in membership_ids])
    query = f"INSERT INTO review (review_id, FK_Mem_ID) VALUES ({fake_review_id}, {fake_membership_id})"
    mycursor.execute(query)
    

#items

for _ in range(600):
    mycursor.execute("SELECT Paper_ID FROM discount_paper")
    paper_ids=mycursor.fetchall()
    fake_paper_id = fake.random_element(elements=[id[0] for id in paper_ids])
    mycursor.execute("SELECT Employee_ID FROM stock_clerk")
    clerk_ids=mycursor.fetchall()
    fake_clerk_id = fake.random_element(elements=[id[0] for id in clerk_ids])
   
    query = f"""
        UPDATE items
        SET FK_Paper_ID = {fake_paper_id}, FK_Clerk_ID = {fake_clerk_id}
        WHERE FK_Paper_ID IS NULL AND FK_Clerk_ID IS NULL
        LIMIT 1;
        """
    mycursor.execute(query)
    




#brings

for _ in range(200):
    #fake_review_id = fake.unique.random_number(digits=5)
    mycursor.execute("SELECT barcode_number FROM items")
    barcode_numbers=mycursor.fetchall()
    fake_barcode_numbers = fake.random_element(elements=[id[0] for id in barcode_numbers])   
    mycursor.execute("SELECT supplier_id FROM supplier")
    supplier_ids=mycursor.fetchall() 
    fake_supplier_ids = fake.random_element(elements=[id[0] for id in supplier_ids])   
    query = f"INSERT INTO brings (FK_barcode_number, FK_supplier_id) VALUES ({fake_barcode_numbers}, {fake_supplier_ids})"
    mycursor.execute(query)   


#receipt
for _ in range(200):
    fake_receipt_id = fake.unique.random_number(digits=5)

    mycursor.execute("SELECT Membership_ID FROM customer")
    membership_ids = mycursor.fetchall()
    fake_mem_id = fake.random_element(elements=[id[0] for id in membership_ids])

    query = f"INSERT INTO receipt (receipt_number, FK_Mem_ID) VALUES ({fake_receipt_id}, {fake_mem_id})"
    mycursor.execute(query)
    
#writes
for _ in range(200):
    mycursor.execute("SELECT review_id FROM review")
    review_ids=mycursor.fetchall()
    mycursor.execute("SELECT Membership_ID FROM customer")
    membership_ids=mycursor.fetchall()
    fake_review_id = fake.random_element(elements=[id[0] for id in review_ids])
    fake_membership_id = fake.random_element(elements=[id[0] for id in membership_ids])
    query = f"INSERT INTO writes (FK_review_id, FK_membership_id) VALUES ({fake_review_id}, {fake_membership_id})"
    mycursor.execute(query)

#uses
for _ in range(200):
    mycursor.execute("SELECT Membership_ID FROM customer")
    membership_ids = mycursor.fetchall()
    fake_mem_id = fake.random_element(elements=[id[0] for id in membership_ids])
    mycursor.execute("SELECT Employee_ID FROM employees")
    emp_ids = mycursor.fetchall()
    fake_emp_id = fake.random_element(elements=[id[0] for id in emp_ids])

    mycursor.execute("SELECT bathroom_id FROM bathroom")
    bathroom_ids = mycursor.fetchall()
    fake_bathroom_id = fake.random_element(elements=[id[0] for id in bathroom_ids])

    query = f"INSERT INTO uses (FK_membership_id, FK_employee_id, FK_bathroom_id) VALUES ({fake_mem_id}, {fake_emp_id}, {fake_bathroom_id})"
    mycursor.execute(query)
mydb.commit()






        
        